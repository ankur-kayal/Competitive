#pragma once

#include "tcframe/runner/evaluator/scorer/CustomScorer.hpp"
#include "tcframe/runner/evaluator/scorer/DiffScorer.hpp"
#include "tcframe/runner/evaluator/scorer/Scorer.hpp"
#include "tcframe/runner/evaluator/scorer/ScoringResult.hpp"
