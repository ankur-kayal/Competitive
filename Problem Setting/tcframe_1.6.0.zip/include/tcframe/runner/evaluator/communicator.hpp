#pragma once

#include "tcframe/runner/evaluator/communicator/CommunicationResult.hpp"
#include "tcframe/runner/evaluator/communicator/Communicator.hpp"
