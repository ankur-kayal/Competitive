#pragma once

#include "tcframe/runner/os/ExecutionResult.hpp"
#include "tcframe/runner/os/ExecutionRequest.hpp"
#include "tcframe/runner/os/OperatingSystem.hpp"
#include "tcframe/runner/os/TestCasePathCreator.hpp"
