#pragma once

#include "tcframe/runner/verdict/Verdict.hpp"
#include "tcframe/runner/verdict/VerdictCreator.hpp"
#include "tcframe/runner/verdict/VerdictStatus.hpp"
