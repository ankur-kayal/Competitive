#pragma once

#include "tcframe/runner/aggregator/Aggregator.hpp"
#include "tcframe/runner/aggregator/AggregatorRegistry.hpp"
#include "tcframe/runner/aggregator/MinAggregator.hpp"
#include "tcframe/runner/aggregator/SumAggregator.hpp"
