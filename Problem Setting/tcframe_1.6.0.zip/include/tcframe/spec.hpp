#pragma once

#include "tcframe/spec/constraint.hpp"
#include "tcframe/spec/core.hpp"
#include "tcframe/spec/io.hpp"
#include "tcframe/spec/random.hpp"
#include "tcframe/spec/testcase.hpp"
#include "tcframe/spec/variable.hpp"
#include "tcframe/spec/verifier.hpp"

