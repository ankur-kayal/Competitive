#pragma once

#include "tcframe/spec/constraint/Constraint.hpp"
#include "tcframe/spec/constraint/ConstraintSuite.hpp"
#include "tcframe/spec/constraint/Subtask.hpp"
