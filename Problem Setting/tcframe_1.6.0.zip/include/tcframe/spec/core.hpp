#pragma once

#include "tcframe/spec/core/BaseProblemSpec.hpp"
#include "tcframe/spec/core/BaseTestSpec.hpp"
#include "tcframe/spec/core/Magic.hpp"
#include "tcframe/spec/core/SeedSetter.hpp"
#include "tcframe/spec/core/SpecYaml.hpp"
