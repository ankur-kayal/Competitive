#pragma once

#include "tcframe/spec/config/GradingConfig.hpp"
#include "tcframe/spec/config/MultipleTestCasesConfig.hpp"
#include "tcframe/spec/config/StyleConfig.hpp"
