#pragma once

#include "tcframe/spec/verifier/ConstraintsVerificationResult.hpp"
#include "tcframe/spec/verifier/MultipleTestCasesConstraintsVerificationResult.hpp"
#include "tcframe/spec/verifier/Verifier.hpp"
