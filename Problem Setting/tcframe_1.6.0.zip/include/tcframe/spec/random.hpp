#pragma once

#include "tcframe/spec/random/Random.hpp"
