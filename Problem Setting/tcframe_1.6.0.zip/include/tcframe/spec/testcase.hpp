#pragma once

#include "tcframe/spec/testcase/OfficialTestCaseData.hpp"
#include "tcframe/spec/testcase/SampleTestCaseData.hpp"
#include "tcframe/spec/testcase/TestCase.hpp"
#include "tcframe/spec/testcase/TestCaseData.hpp"
#include "tcframe/spec/testcase/TestGroup.hpp"
#include "tcframe/spec/testcase/TestSuite.hpp"
