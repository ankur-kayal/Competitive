#pragma once

#include "tcframe/spec/variable/Matrix.hpp"
#include "tcframe/spec/variable/Scalar.hpp"
#include "tcframe/spec/variable/TokenFormatter.hpp"
#include "tcframe/spec/variable/Variable.hpp"
#include "tcframe/spec/variable/Vector.hpp"
#include "tcframe/spec/variable/WhitespaceManipulator.hpp"
